# Artificial Intelligence and Machine Learning for SupTech
This repo contains the course material for the Artificial Intelligence and Machine Learning for SupTech course. 

The tutorials can be found in the tutorial folder.
